Wiki2Beamer
http://www.repc.de/wiki2beamer

----------------------------------------------------------------------
Create latex beamer sources for multiple frames from a wiki-like code.

Current version: 0.6
Author: Michael Rentzsch (http://www.repc.de)

Thanks to Kai Dietrich <mail@cleeus.de> for providing his
frame-close-detection patch.
----------------------------------------------------------------------

Licensed under the terms of the GPL (see gpl.txt).
