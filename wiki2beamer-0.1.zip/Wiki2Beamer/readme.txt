Wiki2Beamer
http://www.repc.de/wiki2beamer

----------------------------------------------------------------------
Create latex beamer sources for multiple frames from a wiki-like code.

Current version: 0.1
Author: Michael Rentzsch (http://www.repc.de)
----------------------------------------------------------------------

Licensed under the terms of the GPL (see gpl.txt).
